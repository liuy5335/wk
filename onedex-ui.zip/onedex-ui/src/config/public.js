import env from './env';

export default {
  chainSymbol: env === 'dev' ? 'QILINEOS' : 'EOS',
  defaultSource: env === 'dev' ? 'hello23zhang' : 'onedex123451',
};
