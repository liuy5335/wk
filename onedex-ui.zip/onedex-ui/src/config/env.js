// const env = 'dev';
const env = 'pro';

export default env;
