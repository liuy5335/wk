import scatterConfig from './scatterConfig';
import publicCfg from './public';

export default {
  scatterConfig,
  publicCfg,
};
