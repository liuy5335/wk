<template>
  <div class="search">
      <div class="tools">
          <span class="iconfont icon-huaban20 searchIcon"></span>
          <span class="inputDiv">
              <input class="color-333" type="text" :placeholder="$t('public.search')" v-model="searchKey">
          </span>
          <span class="iconfont icon-huaban17 closeIcon" @click="handleClose"></span>
      </div>
      <div class="tradeTable">
          <div class="item"
               v-for="(item, index) in searchRes" :key="index" @click="handleToTrade(item)">
              <div class="symbolName">
                  {{ item.name.toUpperCase() }}
                  <img class="img-mark" :src="item.authentication ? goodIcon : warnIcon" alt="">
                  <br>
                  <span class="publishAccount color-999">{{item.code2}}</span>
              </div>
              <div class="symbolPrice">{{ handleToFixed(item.price, item.precision.price) }}</div>
              <div class="symbolChange"
                   :class="{'color-red': item.change < 0,'color-999':item.change === 0,'color-green':item.change > 0}">
                  <span v-if="item.change > 0">+</span>{{ handleToFixed(item.change, 2) }}%
              </div>
          </div>
      </div>
  </div>
</template>

<script>
import { toLocalTime, toFixed } from '@/utils/public';
import goodIcon from '@/assets/img/good.png';
import warnIcon from '@/assets/img/warn.png';

export default {
  data() {
    return {
      goodIcon,
      warnIcon,
      isIOS: false,
      searchKey: '',
      searchRes: [],
    };
  },
  props: [
    'searchData',
  ],
  computed: {
    data() {
      return this.searchData ? this.searchData.eos : [];
    },
  },
  watch: {
    searchKey(newVal) {
      this.search(newVal);
    },
  },
  mounted() {
  },
  methods: {
    handleClose() {
      this.$emit('close');
    },
    handleToFixed(num, p) {
      return toFixed(num, p);
    },
    search(key) {
      const arr = [];
      this.data.forEach((v) => {
        const index = v.name2.indexOf(key.toUpperCase())
        if (index > -1) {
          if (index === 0 && key.length === v.name2.length) {
            arr.unshift(v);
          } else {
            arr.push(v)
          }
        }
      });
      this.searchRes = key ? arr : [];
    },
    handleToTrade(item) {
      this.$store.dispatch('setSymbolInfo', item); // 设置交易对信息
      this.$store.dispatch('setPrecision', item.precision); // 设置精度
      const params = {
        symbol: `${item.name2}_${item.name1}`,
      };
      this.$router.push({
        name: 'trade',
        params,
      });
      // 交易页面切换币种时，刷新页面
      if (this.$route.name === 'trade') {
        this.$emit('listenClose', false);
        // this.$router.go(0);
      }
    },
  },
};
</script>

<style scoped lang="scss">
@import "../assets/css/public.scss";

@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {
  .searchDiv{
    height: calc(100vh - .6rem) !important;
  }
}

.search{
  width: 5.6rem;
  height: 100vh;
  box-sizing: border-box;
  font-size: .32rem;
  background: #fff;
  // padding: .36rem;
    .tools{
        display: flex;
        align-items: center;/*垂直居中*/
        height: .9rem;
        padding: 0 .4rem;
        background: #FFF;
        border-bottom: .02rem solid #999;

        .searchIcon{
            font-size: .35rem;
            color: $color-999;
        }

        .inputDiv{
            flex: 1;
            padding: 0 .2rem;
            &>input{
                width: 100%;
                height: .9rem;
                font-size: .32rem;
            }
        }

        .closeIcon{
            font-size: .35rem;
            color: $color-999;
        }
    }

    .tradeTable{
        font-size: .28rem;
        box-sizing: border-box;
        height: 100%;
        overflow: auto;

        .item{
            min-height: .8rem;
            padding: 0 .3rem;
            border-top: 1px solid transparent;
            border-bottom: 1px solid transparent;
            display: flex;
            align-items: center;/*垂直居中*/
            // justify-content: center;/*水平居中*/

            &.active{
                // box-shadow: 0px 0px 1px $color-this inset;
                border-top: 1px solid rgba(74,144,226,0.24);
                border-bottom: 1px solid rgba(74,144,226,0.24);
                background: rgba(74,144,226,0.11);
            }

            &>div{
                flex: 1;
            }

            .symbolName{
                // font-weight: bold;
                min-width: 2.1rem;
                .img-mark {
                    width: .28rem;
                    height: .28rem;
                }
                .publishAccount {
                    font-size: .24rem;
                }
            }

            .symbolPrice{
                font-size: .25rem;
            }

            .symbolPrice,
            .symbolChange{
                text-align: right;
            }
        }
    }
}

</style>
