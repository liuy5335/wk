<template>
  <div class="tradeRight">
    <!-- 卖盘列表 -->
    <div class="listHead color-999">
      <span>{{ $t('public.price') }}</span>
      <span class="fr mr5">{{ $t('public.count') }}</span>
    </div>
    <div class="list">
      <div class="listContent"  v-for="(item, $index) in asks" :key="$index" @click="handleClickPrice(item.price)">
        <span class="color-red" style="padding-left: .1rem">{{ item.price }}</span>
        <span class="fr mr5 color-999 numWidth" v-if="item.num <= 100000">{{ item.num }}</span>
        <span class="fr mr5 color-999 numWidth" v-if="item.num > 100000">{{ toFixed(item.num / 1000, 1) }}K</span>
        <div class="bgColor" :style="`width: ${handleBgWidth(item.num, sellCount)}%`"></div>
      </div>
    </div>

    <!-- 最新价 -->
    <div class="newPrice" :class="{'color-green': symbolData.change > 0,'color-red': symbolData.change < 0}">
      {{ toFixed(symbolData.price, symbolData.precision.price) }}
      <span class="iconfont icon-huaban39 icon" v-if="symbolData.change > 0"></span>
      <span class="iconfont icon-huaban40 icon" v-if="symbolData.change < 0"></span>
    </div>

    <!-- 买盘列表 -->
    <div class="list">
      <div class="listContent" v-for="(item, $index) in bids" :key="$index" @click="handleClickPrice(item.price)">
        <span class="color-green" style="padding-left: .1rem">{{ item.price }}</span>
        <span class="fr mr5 color-999 numWidth" v-if="item.num < 100000">{{ item.num }}</span>
        <span class="fr mr5 color-999 numWidth" v-if="item.num >= 100000">{{ toFixed(item.num / 1000, 1) }}K</span>
        <div class="bgColor bgColorBuy" :style="`width: ${handleBgWidth(item.num, buyCount)}%`"></div>
      </div>
    </div>
  </div>
</template>

<script>
// JS
import { Decimal } from 'decimal.js';
import { toFixed } from '@/utils/public';
import { api } from '@/api';
import DApp from '@/utils/moreWallet';

export default {
  data() {
    return {
      symbol: 'iq_eos',
      wsData: { // ws 原数据
        asks: [], // 卖盘深度
        bids: [], // 买盘深度
      },
      asks: [], // 卖盘深度
      bids: [], // 买盘深度
      buyCount: 0,
      sellCount: 0,
      first: true,
      symbolData: this.$store.state.app.symbolInfo,
      timer: 0,
      newList: {
        asks: [],
        bids: [],
      },
    };
  },
  props: [
    'symbolInfo',
    'newPrice',
  ],
  components: {
  },
  watch: {
    '$store.state.app.trad': function listen(newVal) {
      // this.clearAll()
      this.symbolInfo = newVal;
      // this.handlePriceDepthWs();
      // this.handleDepthData(this.wsData);
    },
    '$store.state.app.scope': function listen() {
      this.clearAll()
      this.handleMouted();
    },
    '$route.params.symbol': function listen() {
      this.handleMouted();
    },
    symbolInfo () {
      // this.clearAll()
      // this.handleMouted();
    }
  },
  created() {
  },
  mounted() {
      this.clearAll()
  },
  methods: {
    clearAll () {
      this.newList = {
        asks: [],
        bids: [],
      };
        this.asks = []
        this.bids = []
    },
    // vue挂载时调用
    handleMouted() {
      this.symbol = this.$route.params.symbol.toUpperCase();
      this.handlePriceDepthWs();
    },

    // 截取小数
    toFixed(numb, p) {
      return toFixed(numb, p);
    },

    // 获取深度数据
    handlePriceDepthWs() {
      console.log('get')
      clearInterval(this.timer);
      this.newList = {
        asks: [],
        bids: [],
      };
      DApp.obj.getBidData().then((res) => {
        const bidRows = res.rows;
        bidRows.forEach((v, i) => {
          this.newList.bids.push({
            price: v.price / 100000000,
            amount: v.quantity.split(' ')[0],
          });
        });
        DApp.obj.getAskData().then((res) => {
          const askRows = res.rows;
          askRows.forEach((v, i) => {
            this.newList.asks.push({
              price: v.price / 100000000,
              amount: v.quantity.split(' ')[0],
            });
          });
          console.log('end')
          this.handleDepthData(this.newList);
          // 卖盘列表显示到最后
          if (this.first) {
            this.first = false;
            setTimeout(() => {
              document.getElementsByClassName('list')[0].scrollTop = 10000;
            }, 100);
          }
        });
      });

      this.$http.get(api.tradeQuatationsList, {
        params: {
          symbol: this.$store.state.app.symbolInfo.symbol,
        },
      }).then((res) => {
        const { list } = res.data;
        this.symbolData.price = list[0] ?  list[0].latest : 0;
      });

      this.timer = setInterval(this.handlePriceDepthWs, 10000);
    },

    // 处理数据 - 精度
    handleDepthData(data) {
      const asks = [];
      this.sellCount = 0;
      const top = this.distinct(data.asks);
      const bom = this.distinct(data.bids);
      top.forEach((v) => {
        asks.push({
          price: toFixed(Number(v.price), this.symbolData.precision.price),
          num: toFixed(Number(v.amount), this.symbolData.precision.coin),
        });
        if (this.sellCount < Number(v.amount)) {
          this.sellCount = Number(v.amount);
        }
        // this.sellCount += Number(vv[1]);
      });
      // 卖盘需要进行倒序
      this.asks = asks.reverse();

      const bids = [];
      this.buyCount = 0;
      bom.forEach((v) => {
        bids.push({
          price: toFixed(Number(v.price), this.symbolData.precision.price),
          num: toFixed(Number(v.amount), this.symbolData.precision.coin),
        });
        if (this.buyCount < Number(v.amount)) {
          this.buyCount = Number(v.amount);
        }
        // this.buyCount += Number(vv[1]);
      });
      this.bids = bids.reverse();
      console.log('change')
    },
    // 合并价格相同的数据
    distinct(arr) {
      let len = arr.length || 0;
      for (let i = 0; i < len; i++) {
        for (let j = i + 1; j < len; j++) {
          if (arr[i].price === arr[j].price) {
            arr[i].amount = Decimal.add(Number(arr[i].amount), Number(arr[j].amount));
            arr.splice(j, 1);
            len--;
            j--;
          }
        }
      }
      return arr;
    },

    // 交易量背景色
    handleBgWidth(num, count) {
      // console.log(count, (num / count) * 100)
      return (num / Number(count)) * 100;
    },
    // 价格点击
    handleClickPrice(data) {
      this.$store.dispatch('setClickPrice', data);
    },
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
};
</script>

<style scoped lang="scss">
@import "../../../assets/css/public.scss";

.mr5{
  margin-right: .09rem;
}

.tradeRight{
  font-size: .25rem;
  padding-bottom: .2rem;

  .listHead{
    // font-weight: 300;
    line-height: .8rem;
    height: .8rem;;
  }

  .list{
    max-height: 3.2rem;
    overflow: auto;

    .listContent{
      position: relative;
      height: .44rem;
      line-height: .44rem;
      margin: .1rem 0;

      .numWidth{
        max-width: 1.5rem;
        overflow: hidden;
      }

      .bgColor{
        position: absolute;
        height: .4rem;
        width: 50%;
        background: $color-sell;
        top: 0px;
        right: 0px;
        border-radius: .03rem;
      }

      .bgColorBuy{
        background: $color-buy;
      }
    }
  }

  .newPrice{
    text-align: center;
    height: .65rem;
    line-height: .67rem;
    border-top: 1px solid $color-e3e3e3;
    border-bottom: 1px solid $color-e3e3e3;
    margin: .24rem 0;
    font-size: .3rem;
    display: flex;
    align-items: center;/*垂直居中*/
    justify-content: center;/*水平居中*/

    .icon{
      font-size: .24rem;
    }
  }
}
</style>
