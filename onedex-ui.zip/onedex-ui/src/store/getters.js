const getters = {
  app: state => state.app,
};

export default getters;
