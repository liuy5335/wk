import env from './env';
import axios from 'axios';
import { api } from '@/api';

// const node = {
//   qi: '',
//   eos: '',
// };
// axios.get(api.getChainInfo).then((res) => {
//   const data = res.data.data;
//   data.list.forEach((v) => {
//     if (v.symbol === 'QILINEOS') {
//       node.qi = {
//         chain_id: v.chain_id,
//         source: v.source_account,
//         agree: v.wallet_host_path,
//         host: v.wallet_host,
//         port: v.wallet_host_port,
//       };
//     }
//     if (v.symbol === 'EOS') {
//       node.eos = {
//         chain_id: v.chain_id,
//         source: v.source_account,
//         agree: v.wallet_host_path,
//         host: v.wallet_host,
//         port: v.wallet_host_port,
//       };
//     }
//   });
// });

const nodeConfig = env === 'dev' ? /* {
    blockchain: 'eos',
    contract: 'onetest12345',
    httpEndpoint: 'http://120.220.14.90:18000',
    protocol: 'http',
    host: '120.220.14.90',
    port: 18000,
    chainId: '6c6233014b24ca2d291676e19c3a8cfe2fcca4e70d3878ec092346a62b5ade9a',
  } */ {
    blockchain: 'eos',
    contract: 'hello23zhang',
    httpEndpoint: 'http://kylin.meet.one:8888',
    protocol: 'http',
    host: 'kylin.meet.one',
    port: 8888,
    chainId: '5fff1dae8dc8e2fc4d5b23b2c7665c97f9e9d8edf2b6485a86ba311c25639191',
  } :
  {
    blockchain: 'eos',
    contract: 'onedex123451',
    httpEndpoint: 'https://eosnode-cq.coinrr.com:443',
    protocol: 'https',
    host: 'eosnode-cq.coinrr.com',
    port: 443,
    chainId: 'aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906',
  };

const scatterConfig = {
  contract: nodeConfig.contract,
  eosConfig: {
    httpEndpoint: nodeConfig.httpEndpoint,
    chainId: nodeConfig.chainId,
  },
  network: {
    blockchain: nodeConfig.blockchain,
    protocol: nodeConfig.protocol,
    host: nodeConfig.host,
    port: nodeConfig.port,
    chainId: nodeConfig.chainId,
  },
  eosOptions: {
    broadcast: true,
    sign: true,
    chainId: nodeConfig.chainId,
  },
};

export default scatterConfig;
