<template>
    <div class="footer color-999">
      <div class="footerTip">{{ $t('footer.tip') }}</div>
      <div class="footerTip">&copy;2018 OneChain.one,All right reserved</div>
    </div>
</template>

<script>
// import Language from '@/components/Language';

export default {

};
</script>
